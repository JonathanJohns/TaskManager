@extends('admin.layouts.app')

@section('_active')
active
@endsection


@section('modals')


@endsection



@section('content')




    
@endsection




@section('script')


@endsection