<footer class="footer">
    <div class="container-fluid">
        {{-- <nav class="pull-left">
            <ul>
                <li>
                    <a href="/login">
                        Home
                    </a>
                </li>
                
            </ul>
        </nav> --}}
        <p class="copyright pull-right">
            &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.ecowebplus.com">Ecowebplus</a>, made by creative minds
        </p>
    </div>
</footer>