<div class="sidebar" data-color="red" data-image="<?php echo e(asset('assets/img/sidebar-4.jpg')); ?>">
    
    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="/dashboard" class="simple-text">
                    Eco-Task
                </a>
            </div>

            <ul class="nav">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super-admin', Auth::user()->roles)): ?>
                <li class="<?php echo $__env->yieldContent('dashboard_active'); ?>">
                    <a href="/dashboard">
                        <i class="pe-7s-graph"></i>
                        <p>Admin</p>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('super-admin', Auth::user()->roles)): ?>
                <li class="<?php echo $__env->yieldContent('view_task_active'); ?>">
                    <a href="<?php echo e(route('tasks.index')); ?>">
                        <i class="pe-7s-note2"></i>
                        <p>Tasks</p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super-admin', Auth::user()->roles)): ?>
                <li class="<?php echo $__env->yieldContent('settings_active'); ?>">
                    <a href="<?php echo e(route('settings')); ?>">
                        <i class="pe-7s-settings"></i>
                        <p>Settings</p>
                    </a>
                </li>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>