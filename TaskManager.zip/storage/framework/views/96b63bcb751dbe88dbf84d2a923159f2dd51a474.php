<body>

    <?php echo $__env->yieldContent('modals'); ?>
    <div class="wrapper">

        <?php echo $__env->make('admin.includes.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="main-panel">

            <?php echo $__env->make('admin.includes.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="content">

                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                   
                </div>
                 
            </div>
            <?php echo $__env->make('admin.includes.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    
    
</body>
    