<nav class="navbar navbar-default navbar-fixed">
    <div class="container-fluid">
         <div class="navbar-header">
            
            <a class="navbar-brand" href="#"><?php echo $__env->yieldContent('page_name'); ?></a>
        </div> 
        <div class="collapse navbar-collapse">
            

            <ul class="nav navbar-nav navbar-right">
                
                <li class="dropdown">
                        
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <p><i class="pe-7s-user"></i>
                                <?php echo e(Auth::user()->name); ?>

                                <b class="caret"></b>
                            </p>

                      </a>
                      <ul class="dropdown-menu">
                        <li><a href="#">View Profile</a></li>
                        <li><a href="#">View All Tasks</a></li>
                        <li class="divider"></li>
                        <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                                 <?php echo e(__('Logout')); ?>

                             </a>
    
                             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                 <?php echo csrf_field(); ?>
                             </form>
                        </li>
                      </ul>
                </li>
                
                <li>
                    
                            
                    
                </li>
                <li class="separator hidden-lg"></li>
            </ul>
        </div>
    </div>
</nav>